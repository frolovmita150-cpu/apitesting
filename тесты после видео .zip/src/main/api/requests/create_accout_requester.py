
from main.api.models.create_account_response import CreateAccountRessponce
from src.main.api.requests.requester import Requester
import requests


class CreateAccountRequester(Requester):
    def post(self, model=None) -> CreateAccountRessponce:
        url=f"{self.base_url}/account/create"
        response = requests.post(
            url=url,
            headers=self.headers,
        )
        self.response_spec(response)
        return CreateAccountRessponce(**response.json())
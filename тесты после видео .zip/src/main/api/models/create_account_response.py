from src.main.api.models.base_model import BaseModel
class CreateAccountRessponce(BaseModel):
    id : int
    number : str
    balance : float
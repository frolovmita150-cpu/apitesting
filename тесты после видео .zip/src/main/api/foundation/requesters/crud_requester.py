from typing import Optional
import requests
import allure
from main.api.configs.config import Config
from main.api.foundation.http_requster import HTTPRequester
from main.api.models.base_model import BaseModel
from requests import Response


class CrudRequester(HTTPRequester):
    def post(self, model: Optional[BaseModel] ) -> Response:
        body = model.model_dump() if model is not None else ''

        with allure.step(f"POST {Config.fetch('backendUrl')}{self.endpoint.value.url}"):
            allure.attach (str(body), "Request  body", allure.attachment_type.JSON)

        response = requests.post(
            url=f"{Config.fetch('backendUrl')}{self.endpoint.value.url}",
            headers=self.request_spec,
            json = body

        )

        allure.attach (
            response.text,
            "Response body",
            allure.attachment_type.JSON
        )
        self.response_spec(response)
        return response

    def delete(self, user_id: int) -> Response:
        response = requests.delete(
            url=f"{Config.fetch('backendUrl')}{self.endpoint.value.url}/{user_id}",
            headers=self.request_spec
        )
        self.response_spec(response)
        return response